# Add project specific ProGuard rules here.
-keep class com.autobt4g.app.** { *; }
