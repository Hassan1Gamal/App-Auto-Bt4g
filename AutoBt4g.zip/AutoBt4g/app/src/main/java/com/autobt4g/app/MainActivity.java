package com.autobt4g.app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private WebView webView;
    private EditText searchInput;
    private Button searchBtn;
    private ProgressBar progressBar;
    private TextView statusText;

    // نفس الـ JavaScript بتاع الإكستنشن بالظبط
    private static final String AUTO_DL_JS =
        "(function() {" +
        "  var currentUrl = window.location.href;" +

        // الخطوة 1: صفحة البحث - اضغط على أول نتيجة
        "  if (currentUrl.includes('bt4gprx.com/search')) {" +
        "    var link = document.querySelector('.list-group-item h5 a');" +
        "    if (link) {" +
        "      var url = new URL(link.href, window.location.origin);" +
        "      url.searchParams.set('autodl', '1');" +
        "      window.location.href = url.href;" +
        "    } else {" +
        "      AndroidBridge.onStatus('❌ مفيش نتايج');" +
        "    }" +
        "  }" +

        // الخطوة 2: صفحة الماجنت - روح لـ downloadtorrentfile
        "  else if (currentUrl.includes('bt4gprx.com/magnet')) {" +
        "    var btn = document.querySelector('a[href*=\"downloadtorrentfile.com\"]');" +
        "    if (btn) {" +
        "      var url = new URL(btn.href);" +
        "      url.searchParams.set('autodl', '1');" +
        "      window.location.href = url.href;" +
        "    }" +
        "  }" +

        // الخطوة 3: صفحة التحميل النهائية - جيب رابط الماجنت
        "  else if (currentUrl.includes('downloadtorrentfile.com')) {" +
        "    var magnetBtn = document.querySelector('a#open[href^=\"magnet:\"]');" +
        "    if (magnetBtn) {" +
        "      AndroidBridge.openMagnet(magnetBtn.href);" +
        "    } else {" +
        "      AndroidBridge.onStatus('⏳ بتحضر الرابط...');" +
        "      setTimeout(function() { location.reload(); }, 2000);" +
        "    }" +
        "  }" +
        "})();";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchInput = findViewById(R.id.searchInput);
        searchBtn = findViewById(R.id.searchBtn);
        progressBar = findViewById(R.id.progressBar);
        statusText = findViewById(R.id.statusText);
        webView = findViewById(R.id.webView);

        setupWebView();

        // لو التطبيق اتفتح عن طريق Share من تطبيق تاني
        handleShareIntent();

        searchBtn.setOnClickListener(v -> {
            String query = searchInput.getText().toString().trim();
            if (!query.isEmpty()) {
                startSearch(query);
            } else {
                Toast.makeText(this, "اكتب اسم الفيلم أو المسلسل", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setUserAgentString(
            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36"
        );

        // الـ Bridge بين JavaScript والتطبيق
        webView.addJavascriptInterface(new Object() {

            @android.webkit.JavascriptInterface
            public void openMagnet(String magnetUrl) {
                runOnUiThread(() -> {
                    statusText.setText("✅ تم! بيفتح التورنت...");
                    progressBar.setVisibility(View.GONE);
                    webView.setVisibility(View.GONE);

                    // فتح رابط الماجنت في تطبيق التورنت
                    try {
                        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(magnetUrl));
                        startActivity(intent);
                    } catch (Exception e) {
                        statusText.setText("❌ مش لاقي تطبيق تورنت!\nنزّل LibreTorrent من Play Store");
                    }
                });
            }

            @android.webkit.JavascriptInterface
            public void onStatus(String msg) {
                runOnUiThread(() -> statusText.setText(msg));
            }

        }, "AndroidBridge");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // شغّل الـ JavaScript الأوتوماتيك بعد ما الصفحة تتحمل
                if (url.contains("autodl=1")) {
                    webView.evaluateJavascript(AUTO_DL_JS, null);
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });
    }

    private void startSearch(String query) {
        String encodedQuery = Uri.encode(query);
        String url = "https://bt4gprx.com/search?q=" + encodedQuery + "&autodl=1";

        progressBar.setVisibility(View.VISIBLE);
        statusText.setText("🔍 بيدور على: " + query);
        webView.setVisibility(View.VISIBLE);
        webView.loadUrl(url);
    }

    private void handleShareIntent() {
        Intent intent = getIntent();
        if (Intent.ACTION_SEND.equals(intent.getAction())) {
            String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);
            if (sharedText != null && !sharedText.isEmpty()) {
                searchInput.setText(sharedText.trim());
                startSearch(sharedText.trim());
            }
        }
    }
}
