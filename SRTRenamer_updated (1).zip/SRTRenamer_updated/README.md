# SRT Auto Renamer — Android (Kotlin)
**by Hassan Gamal**

## الفكرة
تطبيق Android يقوم بـ:
1. اختيار فولدر الفيلم أو المسلسل
2. اختيار ملف ZIP يحتوي على ترجمة SRT
3. فك الضغط عن الترجمة ووضعها في الفولدر مع تغيير اسمها ليطابق ملف الفيديو

---

## طريقة التشغيل

### المتطلبات
- Android Studio Hedgehog أو أحدث
- Android SDK 24+
- Kotlin 1.9+

### الخطوات
1. افتح Android Studio
2. اختر **"Open"** وحدد مجلد `SRTRenamer`
3. انتظر حتى ينتهي Gradle Sync
4. شغل التطبيق على جهازك أو Emulator

---

## هيكل الملفات

```
SRTRenamer/
├── app/
│   ├── src/main/
│   │   ├── java/com/hassangamal/srtrenamer/
│   │   │   └── MainActivity.kt          ← المنطق الأساسي
│   │   ├── res/
│   │   │   ├── layout/activity_main.xml ← الواجهة
│   │   │   └── values/
│   │   │       ├── colors.xml
│   │   │       ├── strings.xml
│   │   │       └── themes.xml
│   │   └── AndroidManifest.xml
│   └── build.gradle
├── build.gradle
└── settings.gradle
```

---

## كيف يعمل الكود

### 1. المسلسلات (Series)
يبحث عن نمط `S01E01` في اسم الفيديو، ثم يبحث عن نفس النمط في ملفات SRT داخل ZIP.

### 2. الأفلام (Movies)
- يستخرج اسم الفيلم والسنة من اسم الفيديو (مثال: `The.Dark.Knight.2008.mkv`)
- يبحث عن ملف SRT بنفس السنة واسم مشابه 60%+ من الكلمات

### 3. الإخراج
- يفك ZIP ويكتب الـ SRT مباشرة في فولدر الفيديو
- يغير اسمه ليكون مطابقاً تماماً لاسم ملف الفيديو

---

## مثال عملي

**الفيلم:** `The.Dark.Knight.2008.1080p.mkv`
**ZIP يحتوي:** `The.Dark.Knight.2008.BluRay.srt`

**النتيجة:** يُنشأ ملف `The.Dark.Knight.2008.1080p.srt` في نفس الفولدر

---

## ملاحظات
- يدعم `.mkv` و `.mp4` و `.avi`
- يعمل على Android 7.0+ (API 24)
- لا يحتاج permissions خاصة على Android 10+ (يستخدم SAF)
