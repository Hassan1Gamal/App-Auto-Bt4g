package com.hassangamal.srtrenamer

import android.app.Activity
import android.content.*
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.*
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.GestureDetectorCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import java.util.zip.ZipInputStream

class MainActivity : AppCompatActivity() {

    // ── Tab views ────────────────────────────────────────────────────
    private lateinit var tabSrt    : TextView
    private lateinit var tabBt4g   : TextView
    private lateinit var pageSrt   : View
    private lateinit var pageBt4g  : View

    // ── SRT Renamer UI ───────────────────────────────────────────────
    private lateinit var btnSelectFolder   : Button
    private lateinit var tvFolderPath      : TextView
    private lateinit var layoutModeChoice  : android.widget.LinearLayout
    private lateinit var btnModeAuto       : Button
    private lateinit var btnModeManual     : Button
    private lateinit var layoutAutoMode    : android.widget.LinearLayout
    private lateinit var tvDetectedName    : TextView
    private lateinit var btnOpenSubsource  : Button
    private lateinit var btnCheckDownloads : Button
    private lateinit var layoutManualMode  : android.widget.LinearLayout
    private lateinit var btnSelectZip      : Button
    private lateinit var tvZipPath         : TextView
    private lateinit var btnRun            : Button
    private lateinit var layoutStatus      : android.widget.LinearLayout
    private lateinit var progressBar       : ProgressBar
    private lateinit var tvResult          : TextView

    // ── AutoBt4g UI ──────────────────────────────────────────────────
    private lateinit var bt4gSearchInput   : EditText
    private lateinit var bt4gSearchBtn     : Button
    private lateinit var bt4gProgressBar   : ProgressBar
    private lateinit var bt4gStatusText    : TextView
    private lateinit var bt4gWebView       : WebView
    private lateinit var bt4gTopSpacer     : View
    private lateinit var bt4gBottomSpacer  : View

    // ── SRT State ────────────────────────────────────────────────────
    private var selectedFolderUri  : Uri?    = null
    private var selectedZipUri     : Uri?    = null
    private var detectedSlug       : String? = null
    private var detectedName       : String? = null
    private var currentMode        : String  = "none"
    private var wentToSubsource    : Boolean = false

    // ── Swipe ────────────────────────────────────────────────────────
    private lateinit var gestureDetector : GestureDetectorCompat
    private var currentTab : Boolean = true   // true = SRT, false = bt4g

    // ── AutoBt4g JS ──────────────────────────────────────────────────
    private val AUTO_DL_JS = """
        (function() {
          var currentUrl = window.location.href;
          if (currentUrl.includes('bt4gprx.com/search')) {
            var link = document.querySelector('.list-group-item h5 a');
            if (link) {
              var url = new URL(link.href, window.location.origin);
              url.searchParams.set('autodl', '1');
              window.location.href = url.href;
            } else {
              AndroidBridge.onStatus('❌ مفيش نتايج');
            }
          } else if (currentUrl.includes('bt4gprx.com/magnet')) {
            var btn = document.querySelector('a[href*="downloadtorrentfile.com"]');
            if (btn) {
              var url = new URL(btn.href);
              url.searchParams.set('autodl', '1');
              window.location.href = url.href;
            }
          } else if (currentUrl.includes('downloadtorrentfile.com')) {
            var magnetBtn = document.querySelector('a#open[href^="magnet:"]');
            if (magnetBtn) {
              AndroidBridge.openMagnet(magnetBtn.href);
            } else {
              AndroidBridge.onStatus('⏳ بتحضر الرابط...');
              setTimeout(function() { location.reload(); }, 2000);
            }
          }
        })();
    """.trimIndent()

    // ── Launchers ────────────────────────────────────────────────────
    private val selectFolderLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                selectedFolderUri = uri
                onFolderSelected(uri)
            }
        }
    }

    private val selectZipLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                selectedZipUri = uri
                if (currentMode == "auto") {
                    processFiles()
                } else {
                    tvZipPath.text = getFileName(uri) ?: "ZIP selected"
                    tvZipPath.setTextColor(ContextCompat.getColor(this, R.color.color_success))
                    checkRunReady()
                }
            }
        }
    }

    // ── Lifecycle ────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupTabs()
        setupSwipeGesture()
        setupSrtListeners()
        setupBt4g()
        resetToInitialState()
        handleShareIntent()
    }

    private fun bindViews() {
        // Tabs
        tabSrt   = findViewById(R.id.tabSrt)
        tabBt4g  = findViewById(R.id.tabBt4g)
        pageSrt  = findViewById(R.id.pageSrt)
        pageBt4g = findViewById(R.id.pageBt4g)

        // SRT
        btnSelectFolder   = findViewById(R.id.btnSelectFolder)
        tvFolderPath      = findViewById(R.id.tvFolderPath)
        layoutModeChoice  = findViewById(R.id.layoutModeChoice)
        btnModeAuto       = findViewById(R.id.btnModeAuto)
        btnModeManual     = findViewById(R.id.btnModeManual)
        layoutAutoMode    = findViewById(R.id.layoutAutoMode)
        tvDetectedName    = findViewById(R.id.tvDetectedName)
        btnOpenSubsource  = findViewById(R.id.btnOpenSubsource)
        btnCheckDownloads = findViewById(R.id.btnCheckDownloads)
        layoutManualMode  = findViewById(R.id.layoutManualMode)
        btnSelectZip      = findViewById(R.id.btnSelectZip)
        tvZipPath         = findViewById(R.id.tvZipPath)
        btnRun            = findViewById(R.id.btnRun)
        layoutStatus      = findViewById(R.id.layoutStatus)
        progressBar       = findViewById(R.id.progressBar)
        tvResult          = findViewById(R.id.tvResult)

        // Bt4g
        bt4gSearchInput  = findViewById(R.id.bt4gSearchInput)
        bt4gSearchBtn    = findViewById(R.id.bt4gSearchBtn)
        bt4gProgressBar  = findViewById(R.id.bt4gProgressBar)
        bt4gStatusText   = findViewById(R.id.bt4gStatusText)
        bt4gWebView      = findViewById(R.id.bt4gWebView)
        bt4gTopSpacer    = findViewById(R.id.bt4gTopSpacer)
        bt4gBottomSpacer = findViewById(R.id.bt4gBottomSpacer)
    }

    // ── Swipe gesture ────────────────────────────────────────────────
    private fun setupSwipeGesture() {
        val swipeListener = object : GestureDetector.SimpleOnGestureListener() {
            private val SWIPE_MIN_DISTANCE    = 80
            private val SWIPE_MIN_VELOCITY    = 100
            private val SWIPE_MAX_VERTICAL    = 200

            override fun onFling(
                e1: MotionEvent?, e2: MotionEvent,
                velocityX: Float, velocityY: Float
            ): Boolean {
                val e1 = e1 ?: return false
                val dX = e2.x - e1.x
                val dY = e2.y - e1.y
                if (Math.abs(dX) < SWIPE_MIN_DISTANCE) return false
                if (Math.abs(dY) > SWIPE_MAX_VERTICAL) return false
                if (Math.abs(velocityX) < SWIPE_MIN_VELOCITY) return false
                // Swipe left → bt4g tab; swipe right → SRT tab
                if (dX < 0 && currentTab) {
                    switchTab(srt = false); return true
                }
                if (dX > 0 && !currentTab) {
                    switchTab(srt = true);  return true
                }
                return false
            }
        }
        gestureDetector = GestureDetectorCompat(this, swipeListener)
    }

    // Intercept ALL touch events so swipe works even over ScrollView / WebView
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ── Tab switching ────────────────────────────────────────────────
    private fun setupTabs() {
        tabSrt.setOnClickListener  { switchTab(srt = true)  }
        tabBt4g.setOnClickListener { switchTab(srt = false) }
    }

    private fun switchTab(srt: Boolean) {
        currentTab = srt
        pageSrt.visibility  = if (srt) View.VISIBLE else View.GONE
        pageBt4g.visibility = if (srt) View.GONE    else View.VISIBLE

        tabSrt.setTextColor(ContextCompat.getColor(
            this, if (srt) R.color.color_accent else R.color.color_subtitle))
        tabSrt.setBackgroundColor(ContextCompat.getColor(
            this, if (srt) R.color.color_bg else R.color.color_card))

        tabBt4g.setTextColor(ContextCompat.getColor(
            this, if (!srt) R.color.color_accent else R.color.color_subtitle))
        tabBt4g.setBackgroundColor(ContextCompat.getColor(
            this, if (!srt) R.color.color_bg else R.color.color_card))

        // Auto-paste clipboard when opening bt4g tab (only if field is empty)
        if (!srt) pasteClipboardIfEmpty()
    }

    private fun pasteClipboardIfEmpty() {
        if (bt4gSearchInput.text.isNotEmpty()) return          // already has text → skip
        val clip = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        val text = clip.primaryClip
            ?.getItemAt(0)
            ?.coerceToText(this)
            ?.toString()
            ?.trim()
            ?.takeIf { it.isNotBlank() }
            ?: return
        bt4gSearchInput.setText(text)
        bt4gSearchInput.setSelection(text.length)              // cursor at end
        Toast.makeText(this, "📋 تم لصق: $text", Toast.LENGTH_SHORT).show()
    }

    // ── SRT Renamer ──────────────────────────────────────────────────
    private fun setupSrtListeners() {
        btnSelectFolder.setOnClickListener {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }
            selectFolderLauncher.launch(intent)
        }

        btnModeAuto.setOnClickListener   { switchToAutoMode()   }
        btnModeManual.setOnClickListener { switchToManualMode() }

        btnOpenSubsource.setOnClickListener {
            detectedSlug?.let { slug ->
                wentToSubsource = true
                val url = "https://subsource.net/subtitles/$slug"
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
            }
        }

        btnCheckDownloads.setOnClickListener { openDownloadsPicker() }

        btnSelectZip.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"
                addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/zip","application/x-zip-compressed",
                    "application/x-zip","application/octet-stream"
                ))
            }
            selectZipLauncher.launch(intent)
        }

        btnRun.setOnClickListener { processFiles() }
    }

    private fun onFolderSelected(uri: Uri) {
        val segment = uri.lastPathSegment ?: "Unknown"
        val rawName = segment
            .substringAfter(":")
            .substringAfterLast("/")
            .ifBlank { segment }

        tvFolderPath.text = rawName
        tvFolderPath.setTextColor(ContextCompat.getColor(this, R.color.color_success))

        val (slug, friendly) = buildSlugAndName(rawName)
        detectedSlug = slug
        detectedName = friendly

        tvDetectedName.text = "🎬  $friendly"
        layoutModeChoice.visibility = View.VISIBLE
        layoutAutoMode.visibility   = View.GONE
        layoutManualMode.visibility = View.GONE
        btnRun.visibility           = View.GONE
        layoutStatus.visibility     = View.GONE
        currentMode = "none"
    }

    private fun switchToAutoMode() {
        currentMode = "auto"
        layoutAutoMode.visibility    = View.VISIBLE
        layoutManualMode.visibility  = View.GONE
        btnCheckDownloads.visibility = View.GONE
        btnRun.visibility            = View.GONE
        setModeButtonsState(autoSelected = true)
    }

    private fun switchToManualMode() {
        currentMode = "manual"
        layoutManualMode.visibility = View.VISIBLE
        layoutAutoMode.visibility   = View.GONE
        btnRun.visibility           = View.VISIBLE
        btnRun.isEnabled            = false
        btnRun.alpha                = 0.5f
        setModeButtonsState(autoSelected = false)
    }

    private fun setModeButtonsState(autoSelected: Boolean) {
        btnModeAuto.backgroundTintList = ContextCompat.getColorStateList(
            this, if (autoSelected) R.color.color_accent else R.color.color_card)
        btnModeAuto.setTextColor(ContextCompat.getColor(
            this, if (autoSelected) R.color.color_bg else R.color.color_white))

        btnModeManual.backgroundTintList = ContextCompat.getColorStateList(
            this, if (!autoSelected) R.color.color_accent else R.color.color_card)
        btnModeManual.setTextColor(ContextCompat.getColor(
            this, if (!autoSelected) R.color.color_bg else R.color.color_white))
    }

    private fun openDownloadsPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/zip", "application/x-zip-compressed",
                "application/x-zip", "application/octet-stream",
                "application/x-subrip", "text/plain"
            ))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val downloadsUri = Uri.parse(
                    "content://com.android.providers.downloads.documents/root/downloads"
                )
                putExtra(DocumentsContract.EXTRA_INITIAL_URI, downloadsUri)
            }
        }
        selectZipLauncher.launch(intent)
    }

    private fun checkRunReady() {
        val ready = selectedFolderUri != null && selectedZipUri != null
        btnRun.isEnabled = ready
        btnRun.alpha     = if (ready) 1f else 0.5f
    }

    private fun processFiles() {
        val folderUri = selectedFolderUri ?: return
        val zipUri    = selectedZipUri    ?: return

        layoutStatus.visibility = View.VISIBLE
        progressBar.visibility  = View.VISIBLE
        tvResult.text           = "Processing..."
        tvResult.setTextColor(ContextCompat.getColor(this, R.color.color_white))
        setButtonsEnabled(false)

        CoroutineScope(Dispatchers.IO).launch {
            val result = try {
                val srts = extractSrtsFromUri(zipUri)
                    ?: return@launch withContext(Dispatchers.Main) {
                        showStatus(false, "Cannot open ZIP")
                        setButtonsEnabled(true)
                    }
                if (srts.isEmpty())
                    ProcessResult(false, "No SRT files found in ZIP")
                else
                    renameAndPlace(folderUri, srts)
            } catch (e: Exception) {
                ProcessResult(false, "Error:\n${e.message}")
            }
            withContext(Dispatchers.Main) {
                showStatus(result.success, result.message)
                setButtonsEnabled(true)
            }
        }
    }

    private fun renameAndPlace(folderUri: Uri, srts: List<ExtractedFile>): ProcessResult {
        val videoFiles = listFilesInFolder(folderUri).filter { f ->
            f.name.substringAfterLast(".").lowercase() in
                    setOf("mkv","mp4","avi","mov","wmv")
        }
        if (videoFiles.isEmpty())
            return ProcessResult(false,
                "No video files found!\nMake sure you selected the right folder.")

        val folderDoc = DocumentFile.fromTreeUri(this, folderUri)!!
        var count = 0

        for (video in videoFiles) {
            val base = video.name.substringBeforeLast(".")
            val sm = Regex("S(\\d+)E(\\d+)", RegexOption.IGNORE_CASE).find(video.name)
            if (sm != null) {
                val (s, e) = sm.destructured
                val pat = Regex("S${s}E${e}", RegexOption.IGNORE_CASE)
                srts.firstOrNull { pat.containsMatchIn(it.name) }?.let { srt ->
                    writeFileToFolder(folderDoc, folderUri, "$base.srt", srt.content)
                    count++
                }
                continue
            }
            val yr = Regex("(19|20)\\d{2}").find(video.name)?.value
            if (yr != null) {
                srts.firstOrNull { srt ->
                    val srtYr = Regex("(19|20)\\d{2}").find(srt.name)?.value
                    srtYr == yr && nameSimilarity(
                        cleanTitle(video.name), cleanTitle(srt.name)) >= 0.5
                }?.let { srt ->
                    writeFileToFolder(folderDoc, folderUri, "$base.srt", srt.content)
                    count++
                }
            }
        }

        if (count == 0 && srts.isNotEmpty() && videoFiles.isNotEmpty()) {
            val base = videoFiles.first().name.substringBeforeLast(".")
            writeFileToFolder(folderDoc, folderUri, "$base.srt", srts.first().content)
            count = 1
        }

        return if (count > 0)
            ProcessResult(true, "Done! ✓\n$count subtitle(s) renamed & placed")
        else
            ProcessResult(false, "No matching files found")
    }

    // ── AutoBt4g ────────────────────────────────────────────────────
    private var bt4gPendingQuery: String? = null
    private var bt4gCfRetries  : Int     = 0

    private fun setupBt4g() {
        android.webkit.CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(bt4gWebView, true)
        }

        bt4gWebView.settings.apply {
            javaScriptEnabled          = true
            domStorageEnabled          = true
            databaseEnabled            = true
            setSupportZoom(false)
            builtInZoomControls        = false
            loadWithOverviewMode       = true
            useWideViewPort            = true
            allowFileAccess            = false
            mixedContentMode           = android.webkit.WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            userAgentString =
                "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Mobile Safari/537.36"
            cacheMode = android.webkit.WebSettings.LOAD_DEFAULT
        }

        bt4gWebView.addJavascriptInterface(object {
            @JavascriptInterface
            fun openMagnet(magnetUrl: String) {
                runOnUiThread {
                    bt4gStatusText.text = "✅ تم! بيفتح التورنت..."
                    bt4gProgressBar.visibility = View.GONE
                    bt4gWebView.visibility     = View.GONE
                    showBt4gSpacers(true)
                    bt4gCfRetries = 0
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(magnetUrl)))
                    } catch (_: Exception) {
                        bt4gStatusText.text = "❌ مش لاقي تطبيق تورنت!\nنزّل LibreTorrent من Play Store"
                    }
                }
            }

            @JavascriptInterface
            fun onStatus(msg: String) {
                runOnUiThread { bt4gStatusText.text = msg }
            }
        }, "AndroidBridge")

        bt4gWebView.webChromeClient = object : android.webkit.WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress == 100) bt4gProgressBar.visibility = View.GONE
            }
        }

        bt4gWebView.webViewClient = object : WebViewClient() {

            override fun shouldOverrideUrlLoading(
                view: WebView, request: WebResourceRequest
            ): Boolean {
                val url = request.url.toString()
                if (url.startsWith("magnet:")) {
                    runOnUiThread {
                        bt4gStatusText.text = "✅ تم! بيفتح التورنت..."
                        bt4gProgressBar.visibility = View.GONE
                        bt4gWebView.visibility     = View.GONE
                        showBt4gSpacers(true)
                    }
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                    catch (_: Exception) {
                        runOnUiThread {
                            bt4gStatusText.text = "❌ مش لاقي تطبيق تورنت!\nنزّل LibreTorrent"
                        }
                    }
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                bt4gProgressBar.visibility = View.GONE
                android.webkit.CookieManager.getInstance().flush()

                view.evaluateJavascript("""
                    (function(){
                        var title = document.title || '';
                        var body  = document.body ? document.body.innerText : '';
                        if (title.toLowerCase().includes('just a moment') ||
                            title.toLowerCase().includes('checking your browser') ||
                            body.toLowerCase().includes('enable javascript and cookies')) {
                            return 'cf_challenge';
                        }
                        return 'ok';
                    })()
                """.trimIndent()) { result ->
                    val clean = result?.trim('"') ?: "ok"
                    if (clean == "cf_challenge") {
                        if (bt4gCfRetries < 6) {
                            bt4gCfRetries++
                            runOnUiThread {
                                bt4gStatusText.text = "🔐 Cloudflare check... ($bt4gCfRetries/6)"
                            }
                            bt4gWebView.postDelayed({
                                view.evaluateJavascript("window.scrollTo(0,0);", null)
                            }, 2500)
                        } else {
                            runOnUiThread {
                                bt4gStatusText.text = "⚠️ Cloudflare صعبة — جرب تاني"
                                bt4gProgressBar.visibility = View.GONE
                            }
                        }
                        return@evaluateJavascript
                    }

                    bt4gCfRetries = 0
                    if (url.contains("autodl=1")) {
                        bt4gWebView.evaluateJavascript(AUTO_DL_JS, null)
                    }

                    bt4gPendingQuery?.let { q ->
                        bt4gPendingQuery = null
                        bt4gStartSearch(q)
                    }
                }
            }

            override fun onReceivedError(
                view: WebView,
                request: android.webkit.WebResourceRequest,
                error: android.webkit.WebResourceError
            ) {
                if (request.isForMainFrame) {
                    runOnUiThread {
                        bt4gStatusText.text = "❌ خطأ في الاتصال — تأكد من النت"
                        bt4gProgressBar.visibility = View.GONE
                    }
                }
            }
        }

        bt4gSearchBtn.setOnClickListener {
            val query = bt4gSearchInput.text.toString().trim()
            if (query.isNotEmpty()) {
                bt4gCfRetries = 0
                bt4gStartSearch(query)
            } else {
                Toast.makeText(this, "اكتب اسم الفيلم أو المسلسل", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showBt4gSpacers(show: Boolean) {
        val weight = if (show) 1f else 0f
        fun setWeight(v: View, w: Float) {
            val lp = v.layoutParams as android.widget.LinearLayout.LayoutParams
            lp.weight = w
            v.layoutParams = lp
        }
        setWeight(bt4gTopSpacer,    weight)
        setWeight(bt4gBottomSpacer, weight)
    }

    private fun bt4gStartSearch(query: String) {
        val encoded = Uri.encode(query)
        val url     = "https://bt4gprx.com/search?q=$encoded&autodl=1"
        bt4gProgressBar.visibility = View.VISIBLE
        bt4gStatusText.text        = "🔍 بيدور على: $query"
        bt4gWebView.visibility     = View.VISIBLE
        showBt4gSpacers(false)   // collapse spacers so WebView gets full space
        bt4gWebView.loadUrl(url)
    }

    private fun handleShareIntent() {
        if (Intent.ACTION_SEND == intent.action) {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                bt4gSearchInput.setText(sharedText.trim())
                switchTab(srt = false)
                bt4gStartSearch(sharedText.trim())
            }
        }
    }

    // ── File helpers ─────────────────────────────────────────────────
    data class FileEntry(val name: String, val documentId: String)
    data class ExtractedFile(val name: String, val content: ByteArray)
    data class ProcessResult(val success: Boolean, val message: String)

    private fun listFilesInFolder(treeUri: Uri): List<FileEntry> {
        val results = mutableListOf<FileEntry>()
        return try {
            val docId       = DocumentsContract.getTreeDocumentId(treeUri)
            val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            val projection  = arrayOf(
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            contentResolver.query(childrenUri, projection, null, null, null)?.use { c ->
                val ni = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                val ii = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                while (c.moveToNext()) results.add(FileEntry(c.getString(ni), c.getString(ii)))
            }
            results
        } catch (_: Exception) { results }
    }

    private fun extractSrtsFromUri(uri: Uri): List<ExtractedFile>? {
        val results = mutableListOf<ExtractedFile>()
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                ZipInputStream(input).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        if (!entry.isDirectory &&
                            entry.name.substringAfterLast(".").lowercase() in
                            setOf("srt","ass","ssa")) {
                            results.add(ExtractedFile(
                                entry.name.substringAfterLast("/"), zis.readBytes()))
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            results
        } catch (_: Exception) { null }
    }

    private fun writeFileToFolder(
        folder: DocumentFile, treeUri: Uri, fileName: String, content: ByteArray) {
        folder.listFiles().find {
            it.name == fileName || it.name == "$fileName.txt"
        }?.delete()
        val parentDocId = DocumentsContract.getTreeDocumentId(treeUri)
        val parentUri   = DocumentsContract.buildDocumentUriUsingTree(treeUri, parentDocId)
        val nameNoExt   = fileName.removeSuffix(".srt")
        try {
            val newUri = DocumentsContract.createDocument(
                contentResolver, parentUri, "application/x-subrip", nameNoExt) ?: return
            contentResolver.openOutputStream(newUri)?.use { it.write(content) }
            val cur = contentResolver.query(newUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            val created = cur?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            if (created != null && created != fileName)
                DocumentsContract.renameDocument(contentResolver, newUri, fileName)
        } catch (_: Exception) {
            try {
                val fb = DocumentsContract.createDocument(
                    contentResolver, parentUri, "application/octet-stream", fileName) ?: return
                contentResolver.openOutputStream(fb)?.use { it.write(content) }
            } catch (_: Exception) {}
        }
    }

    // ── Name utilities ───────────────────────────────────────────────
    private fun buildSlugAndName(raw: String): Pair<String, String> {
        val validExts = setOf("mkv","mp4","avi","mov","wmv","flv","srt")
        var namePart = raw
        for (ext in validExts) {
            if (namePart.lowercase().endsWith(".$ext")) {
                namePart = namePart.dropLast(ext.length + 1); break
            }
        }
        val yearMatch   = Regex("(19|20)\\d{2}").find(namePart)
        val seasonMatch = Regex("[Ss]\\d{2}[Ee]").find(namePart)
        val cutIndex = when {
            yearMatch != null && seasonMatch != null ->
                minOf(yearMatch.range.first, seasonMatch.range.first)
            yearMatch   != null -> yearMatch.range.first
            seasonMatch != null -> seasonMatch.range.first
            else -> -1
        }
        val year     = yearMatch?.value ?: ""
        val titleRaw = if (cutIndex != -1) namePart.substring(0, cutIndex)
                       else namePart.substringBefore(".")
        val clean    = titleRaw.replace(Regex("[^a-zA-Z0-9]+"), " ").trim()
            .split(" ").joinToString(" ") { w ->
                w.lowercase().replaceFirstChar { it.uppercase() }
            }
        val friendly = if (year.isNotEmpty()) "$clean ($year)" else clean
        val slug     = buildString {
            append(clean.replace(" ", "-").lowercase())
            if (year.isNotEmpty()) append("-$year")
        }.replace(Regex("-+"), "-").trim('-')
        return Pair(slug, friendly)
    }

    private fun cleanTitle(name: String): String {
        val yr    = Regex("(19|20)\\d{2}").find(name)?.range?.first ?: name.length
        val sCode = Regex("[Ss]\\d{2}[Ee]").find(name)?.range?.first ?: name.length
        val cut   = minOf(yr, sCode)
        return name.substring(0, cut).replace(Regex("[^a-zA-Z0-9]"), " ")
            .trim().lowercase()
    }

    private fun nameSimilarity(a: String, b: String): Double {
        val w1 = a.split(" ").filter { it.isNotBlank() }.toSet()
        val w2 = b.split(" ").filter { it.isNotBlank() }.toSet()
        if (w1.isEmpty() || w2.isEmpty()) return 0.0
        return w1.intersect(w2).size.toDouble() / maxOf(w1.size, w2.size)
    }

    private fun getFileName(uri: Uri): String? =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i) else null
            } else null
        }

    // ── UI helpers ───────────────────────────────────────────────────
    private fun showStatus(success: Boolean, msg: String) {
        progressBar.visibility = View.GONE
        layoutStatus.visibility = View.VISIBLE
        tvResult.text = msg
        tvResult.setTextColor(ContextCompat.getColor(
            this, if (success) R.color.color_success else R.color.color_warning))
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        btnSelectFolder.isEnabled = enabled
        btnSelectZip.isEnabled    = enabled
        btnRun.isEnabled          = enabled && selectedFolderUri != null && selectedZipUri != null
    }

    private fun resetToInitialState() {
        layoutModeChoice.visibility  = View.GONE
        layoutAutoMode.visibility    = View.GONE
        layoutManualMode.visibility  = View.GONE
        btnRun.visibility            = View.GONE
        layoutStatus.visibility      = View.GONE
        btnCheckDownloads.visibility = View.GONE
    }

    // ── Lifecycle ────────────────────────────────────────────────────
    override fun onResume() {
        super.onResume()
        if (wentToSubsource && selectedFolderUri != null) {
            wentToSubsource = false
            openDownloadsPicker()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bt4gWebView.destroy()
    }
}
